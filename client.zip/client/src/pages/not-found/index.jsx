function NotFound() {
  return <div></div>;
}

export default NotFound;
