const express = require('express');
const router = express.Router();
const { addToWishlist } = require('../../controllers/shop/wishlistController');

// Route to add a product to wishlist
router.post('/add-to-wishlist', addToWishlist);

module.exports = router;
