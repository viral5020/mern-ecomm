const Wishlist = require('../../models/Wishlist');

// Add product to wishlist
exports.addToWishlist = async (req, res) => {
  try {
    const { productId, userId } = req.body;

    // Check if the product is already in the user's wishlist
    const existingWishlistItem = await Wishlist.findOne({ userId, productId });

    if (existingWishlistItem) {
      return res.status(400).json({ success: false, message: 'Product is already in your wishlist' });
    }

    // Create a new wishlist item
    const wishlistItem = new Wishlist({
      userId,
      productId,
    });

    await wishlistItem.save();

    return res.status(200).json({ success: true, message: 'Product added to wishlist!' });
  } catch (error) {
    console.error('Error adding to wishlist:', error);
    return res.status(500).json({ success: false, message: 'Internal Server Error' });
  }
};
